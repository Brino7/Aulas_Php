<!--
* @ Autor: Anderson Silva Brino
* @ Data: 07/05/2018
* @ Hora: 09:56:38
-->
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Exercicio 01</title>
    </head>
    <body>
        <?php
        $c = 10;
        while ($c >= 1){
            echo "$c<br>";
            $c--;
        }
        ?>
        <!--<a href="">Voltar</a>-->
    </body>
</html>


